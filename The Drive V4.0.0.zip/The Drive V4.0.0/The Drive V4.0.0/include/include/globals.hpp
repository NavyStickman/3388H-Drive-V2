#include "main.h"

extern pros::Motor driveLeftBack;
extern pros::Motor driveLeftFront;
extern pros::Motor driveRightBack;
extern pros::Motor driveRightFront;
extern pros::Motor winchMotor;
extern pros::Motor intakeMotor1;
extern pros::Motor intakeMotor2;

extern pros::ADIDigitalOut expand;

//controller
extern pros::Controller controller;


//misc
