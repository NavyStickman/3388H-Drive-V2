#include "main.h"

void setDriveMotors(int left, int right, bool pto);
void setDrive(bool pto, bool hold);


void translate(int units, int voltage, bool pto);
void rotate(int degree, int direction, bool pto);

void setAutoMotors(int left, int right, bool pto);
void setRelativeMotors(int distance, int velocity, bool pto);

float looparound(int degrees);

void setDriveHold();
void setDriveCoast();


