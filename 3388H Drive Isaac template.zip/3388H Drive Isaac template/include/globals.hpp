#include "main.h"

//controller declarations
extern pros::Controller master;

//global portings
extern int plttmotor;
extern int pltbmotor;
extern int plbtmotor;
extern int plbbmotor;

extern int prttmotor;
extern int prtbmotor;
extern int prbtmotor;
extern int prbbmotor;

extern int pgyro;

//motor declarations
//pros::Motor (motorname)(port#, motor-cartridge, reversedmotor, motorencoders)
extern pros::Motor lttmotor;
extern pros::Motor ltbmotor;
extern pros::Motor lbtmotor;
extern pros::Motor lbbmotor;

extern pros::Motor rttmotor;
extern pros::Motor rtbmotor;
extern pros::Motor rbtmotor;
extern pros::Motor rbbmotor;

//piston declarations
extern pros::ADIDigitalOut tpiston;
extern pros::ADIDigitalOut ptopiston;

extern pros::ADIDigitalOut clawpiston;
extern pros::ADIDigitalOut retractpiston;

//encoders, gyros, inertials, etc

extern pros::IMU LGyro;
extern pros::IMU RGyro;
